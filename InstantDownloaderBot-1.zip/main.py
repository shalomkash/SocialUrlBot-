import os
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
import yt_dlp
import tempfile

# Bot token from environment variable
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Social links
SOCIAL_LINKS = {
    "Instagram": "https://instagram.com/baddiecascade",
    "TikTok": "https://www.tiktok.com/@baddiecascade",
    "YouTube": "https://youtube.com/@baddiecascade",
    "Twitter/X": "https://x.com/BaddieCascade"
}

download_count = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Welcome to InstantDownloaderBot!

Send a YouTube, Instagram, TikTok, or Twitter link to download.")

async def handle_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    text = update.message.text.strip()

    # Save user message link for callback
    context.user_data['link'] = text

    # Ask user to follow accounts
    keyboard = [
        [InlineKeyboardButton("📸 Instagram", url=SOCIAL_LINKS["Instagram"])],
        [InlineKeyboardButton("🎵 TikTok", url=SOCIAL_LINKS["TikTok"])],
        [InlineKeyboardButton("▶️ YouTube", url=SOCIAL_LINKS["YouTube"])],
        [InlineKeyboardButton("🐦 Twitter/X", url=SOCIAL_LINKS["Twitter/X"])],
        [InlineKeyboardButton("✅ I've Followed", callback_data="followed")]
    ]
    await update.message.reply_text(
        "🔔 Please follow all our social accounts first.
Then tap *I've Followed* to get your download.",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def fetch_and_send(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    chat_id = query.message.chat_id
    link = context.user_data.get('link')

    if not link:
        await query.message.reply_text("⚠️ No link found. Please send a valid video/image link first.")
        return

    await query.message.reply_text("⏳ Downloading your file, please wait...")

    try:
        ydl_opts = {
            'outtmpl': os.path.join(tempfile.gettempdir(), '%(title)s.%(ext)s'),
            'format': 'bestvideo+bestaudio/best',
            'noplaylist': True,
            'quiet': True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(link, download=True)
            file_path = ydl.prepare_filename(info)

        # Check file size and send
        if os.path.getsize(file_path) < 49 * 1024 * 1024:
            await context.bot.send_document(chat_id, document=open(file_path, 'rb'), caption="✅ Download complete.")
        else:
            await context.bot.send_message(chat_id, f"📎 File is too large to send.

Here's the title:
{info.get('title')}
And a link you can download from:
{info.get('webpage_url')}")

        # Track and remind
        count = download_count.get(user_id, 0) + 1
        download_count[user_id] = count
        if count % 5 == 0:
            await context.bot.send_message(chat_id, "🔁 Reminder: Keep supporting @baddiecascade 💛")
    except Exception as e:
        await context.bot.send_message(chat_id, f"❌ Error:
{str(e)}")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_link))
    app.add_handler(CallbackQueryHandler(fetch_and_send, pattern="^followed$"))
    app.run_polling()

if __name__ == "__main__":
    main()
